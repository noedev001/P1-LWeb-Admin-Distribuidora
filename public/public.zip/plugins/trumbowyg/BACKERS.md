<h1 align="center">Sponsors &amp; Backers</h1>

Trumbowyg is an MIT-licensed open source project and completely free to use.

However, the amount of effort needed to maintain and develop new features for 
the project is not sustainable without proper financial backing. 
You can support it's ongoing development by being a backer or a sponsor:
 
- [Become a backer or sponsor on Patreon](https://www.patreon.com/alexandredemode)
- [One-time donation via PayPal](https://www.paypal.me/alexandredemode/20eur)

<h2 align="center">Gold sponsors</h2>

<p align="center">
    <a href="https://avot.nl">
        <img src="https://cdn.rawgit.com/Alex-D/Trumbowyg/develop/sponsors/avot.svg" alt="avot®" width="200px"/>
    </a>
</p>

<p align="center">
    <a href="https://www.patreon.com/bePatron?c=1176005&rid=1940456">
        Become a Sponsor
    </a>
</p>

<h2 align="center">Backers</h2>

- Thomas Walli
- Johan Rosenson

<p align="center">
    <a href="https://www.patreon.com/bePatron?c=1176005&rid=1940349">
        Become a Backer
    </a>
</p>
